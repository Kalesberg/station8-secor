const Airtable = require('airtable')

exports.handler = async (event, context) => {
  console.log(context)
  try {
    const base = new Airtable({ apiKey: process.env.AIRTABLE_KEY }).base(process.env.AIRTABLE_BASE_ID)

    const customers = base('Customers')

    return {
      statusCode: 200,
      body: JSON.stringify(customers)
    }
  } catch (err) {
    return { statusCode: 500, body: err.toString() }
  }
}
